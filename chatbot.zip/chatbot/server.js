const express = require('express');
const axios = require('axios');
const path = require('path');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 3001;

// Directly using the API key (not recommended for production)
const OPENAI_API_KEY = 'sk-azmUn8DaF0RdVPfkbTVmJMXvl6z50r_WutrCNwUTukT3BlbkFJCl3hkNzD5lXmGeGjLolTIjT_uSQ3vUFCWf4wPQOmoA';

// Middleware to parse JSON
app.use(express.json());

// Serve static files (HTML, CSS, JS) from the current directory
app.use(express.static(path.join(__dirname)));

// Configure express-session
app.use(
    session({
        secret: 'your-secret-key', // Replace with a strong secret in production
        resave: false,
        saveUninitialized: true,
        cookie: { secure: false }, // Set secure: true if using HTTPS
    })
);

// Endpoint to handle user input and fetch response from OpenAI
app.post('/get-response', async (req, res) => {
    const userInput = req.body.user_input;

    if (!userInput) {
        return res.status(400).json({ assistant_reply: 'User input is required!' });
    }

    // Initialize chat history in the session if not already present
    if (!req.session.chatHistory) {
        req.session.chatHistory = [];
    }

    // Add the user's input to the chat history
    req.session.chatHistory.push({ role: 'user', content: userInput });

    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: 'gpt-3.5-turbo',
                messages: req.session.chatHistory, // Send the chat history to OpenAI
                max_tokens: 150,
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${OPENAI_API_KEY}`,
                }
            }
        );

        const assistantReply = response.data.choices[0].message.content.trim();

        // Add the assistant's reply to the chat history
        req.session.chatHistory.push({ role: 'assistant', content: assistantReply });

        res.json({ assistant_reply: assistantReply });
    } catch (error) {
        console.error('Error:', error.message);
        res.status(500).json({ assistant_reply: 'Sorry, something went wrong! Please try again later.' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
