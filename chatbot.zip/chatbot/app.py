from flask import Flask, render_template, request, jsonify
import openai

app = Flask(__name__)

# Set your OpenAI API key directly
openai.api_key = 'sk-azmUn8DaF0RdVPfkbTVmJMXvl6z50r_WutrCNwUTukT3BlbkFJCl3hkNzD5lXmGeGjLolTIjT_uSQ3vUFCWf4wPQOmoA'

@app.route('/')
def index():
    return render_template('index.html')  # Render the frontend HTML

@app.route('/get-response', methods=['POST'])
def get_response():
    user_input = request.json.get('user_input')
    
    # Initialize conversation history
    messages = [{"role": "system", "content": "You are a helpful assistant."}]
    
    # Append user message to conversation history
    messages.append({"role": "user", "content": user_input})
    
    # Generate a response from OpenAI API
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages
    )
    
    assistant_reply = response['choices'][0]['message']['content']
    
    return jsonify({'assistant_reply': assistant_reply})  # Send back the assistant's response

if __name__ == '__main__':
    app.run(debug=True)
