document.getElementById('send-btn').addEventListener('click', function() {
    let userInput = document.getElementById('user-input').value.trim();
    if (userInput !== "") {
        addMessage(userInput, 'user');
        document.getElementById('user-input').value = "";

        $.ajax({
            url: '/get-response',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ user_input: userInput }),
            success: function(response) {
                let assistantReply = response.assistant_reply;
                addMessage(assistantReply, 'assistant');

                // Detect if the response contains Hindi characters for logging or customization
                if (/[\u0900-\u097F]/.test(assistantReply)) {
                    console.log('Assistant responded in Hindi.');
                }
            },
            error: function(error) {
                console.error('Error:', error);
                addMessage('सर्वर से प्रतिक्रिया प्राप्त करने में समस्या हुई। कृपया पुनः प्रयास करें।', 'assistant');
            }
        });
    }
});

function addMessage(message, sender) {
    let chatBox = document.getElementById('chat-box');
    let messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender === 'user' ? 'user-msg' : 'assistant-msg');
    messageDiv.textContent = message;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}
